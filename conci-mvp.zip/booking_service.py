def book_spa(time: str):
    return {
        "booking_id": "SP12345",
        "status": "confirmed",
        "time": time
    }