def create_ticket(room: str, task: str):
    return {
        "ticket_id": "TICKET789",
        "room": room,
        "task": task,
        "status": "created"
    }