def detect_intent(voice_text: str):
    if "spa" in voice_text.lower():
        return {
            "intent": "book_spa",
            "time": "17:00" if "5" in voice_text else "unknown"
        }
    return {"intent": "unknown"}